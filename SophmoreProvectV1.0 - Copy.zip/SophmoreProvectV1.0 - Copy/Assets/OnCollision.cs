﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnCollision : MonoBehaviour
{
    void OnTrigger(Collider col)
    {
        Application.CancelQuit();
        DestroyImmediate(transform.root);
    }
}
